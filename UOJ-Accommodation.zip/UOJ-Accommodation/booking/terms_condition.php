   <!--Modal Log-out --> 

            <div class="modal fade" id="logout" tabindex="-1">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                </div>
                <div class="modal-body">

<body>
<div class="view">
  <p>
Booking Terms &amp; Conditions
<ol>
  We are eagerly anticipating your arrival and would like to advise you of the following in order to help you with your Accommodation planning.

Should there be a concern with your reservation, respective house owner will contact you shortly and you can confirm your reservation.
<ul>

<li> No pets allowed in all of our Accommodations.</li>
<li> All the tenants should reach the relevant rooms/houses before 08.00 p.m.</li>
<li> Free WIFI access.</li>
<li> Room rates exclusive of government tax and service charge.</li>
<li> Rates are subject to change without prior notice.</li>
<li> Cancellation notification must be made at least 5 days prior to arrival for refund of deposits. Cancellation received within the 5 days period will result to forfeiture of full deposits.</li>
<li> We serve Breakfast, Lunch and Dinner, if you wish you can get your meals from us, but additional charges will be applied.</li>

I have agreed that I will present the following documents upon check in:

<li>Copy of Payment made online.</li>
</ul>
If you have any questions, please email at UOJ-Accommodation@gmail.com or call 0212 218 101

Thank you for choosing UOJ-Accommodation. 
Happy Staying......
We wish you for a bright future ahead.

Respectfully your,

UOJ-Accommodation.
</p>
</div>
</body>
</html>

                </div>
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i> Close</button>
                    
                </div>
              </div> 
              </div>
          </div>      
                                      
          <!--Logout end -->  