

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-xs-12 col-sm-9">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<fieldset>
										<legend><h2 class="text-left"><b>Contact Us</h2></b></legend>
											
									<iframe src="https://www.google.com/maps/d/embed?mid=1jNAtQYGS5fJw3hhnLfO7QnYClxhYn9c&ehbc=2E312F" width="770" height="400"></iframe>
									<p><p> <b> University Student's Complex,</b><br/>
									Sir Pon Ramanathan Road,<br/>
									Jaffna (Inside University of Jaffna).<br/>
										  Call us - 021 221 8100<br/>
										  Email us - info@univ.jfn.ac.lk <br/>
										 
											</p></p>

							</fieldset>		
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
