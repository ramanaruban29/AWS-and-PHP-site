<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-xs-12 col-sm-9">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
						<div class="panel-body">	
					
							<fieldset>
							<iframe src="https://www.google.com/maps/d/embed?mid=1jNAtQYGS5fJw3hhnLfO7QnYClxhYn9c&ehbc=2E312F" width="770" height="400"></iframe>
									<p><i> <b>our strategic position gives an easy access to the central office located at the University of Jaffna premises.Undergraduates can meet our system Admin at the Student Complex and can query and obtain further Accommodation related details. </b>
										
									</i></p>
								

							</fieldset>	
						</div>
					</div>	
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
