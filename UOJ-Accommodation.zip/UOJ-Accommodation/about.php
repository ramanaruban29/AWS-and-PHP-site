
<!DOCTYPE html>
<html>
<head>
<style>
* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>
<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-xs-12 col-sm-9">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<fieldset>
										<legend><h2 class="text-left"> <b> About us </b> </h2></legend>
										
									This website was launched in 2022 as a result of an innovative idea proposed by group-G3 who are currently pursuing Computer Science at University of Jaffna. This site was actually developed as a group project for AWS course in the 3rd year. Since every undergraduate needs a peaceful and pleasant environment to study well and achieve their dreams, they actually need a better accommodation, so to provide them with a wider choice of Accommodation only this site was developed and this site is a profitless site and it will be further managed by University students Union of University of Jaffna. This project was initially developed and deployed by below given team members. <br/>
									</fieldset><br/>
						    <div class="row">
  
  <h2 class="relative max-w-lg mt-5 mb-10 text-4xl font-semibold leading-tight lg:text-5xl"><b>An incredible team of amazing individuals </b></h2>
  <div class="column">
    <img class="relative z-10 w-full rounded-full" src="http://drive.google.com/uc?export=view&id=109KyqFtq4BO4p2935ZrvrIP5pH-zGQTQ" height="200" width="200">
    <div class="space-y-1 text-lg font-medium leading-6">
                        <h3><b>Rangan Ramanaruban</b></h3>
                        <p class="text-blue-600">Team Lead</p>
                    </div>
  </div>
  <div class="column">
    <img class="relative z-20 w-full rounded-full" src="https://drive.google.com/uc?export=view&id=1wEjiIADj0UceOIDBh3zuzsvh4ouu2Q3_"height="200" width="200">
      <div class="space-y-1 text-lg font-medium leading-6">
	 <h3><b>Thilanka Jayasinghe </b></h3>
     <p class="text-blue-600">Frontend Developer </p>
    </div>
  </div>
  <div class="column">
     <img class="relative z-20 w-full rounded-full" src="https://drive.google.com/uc?export=view&id=1gb58mC-PtAgQj0bVZH8ZRBRvkP7TsHxr" height="200" width="200">
  <h3><b>Oshadi Viranga </b></h3>
     <p class="text-blue-600">Backend Developer </p>
    </div>
  </div>
  <div class="column">
   <img class="relative z-20 w-full rounded-full" src="https://drive.google.com/uc?export=view&id=1Hb8wx5pwLlrXDmm8a4QEg0kCo72Yi7YX" height="200" width="200">
  <h3><b>Shasini Piumali </b></h3>
     <p class="text-blue-600">Backend Developer </p>
    </div>
  </div>
  
  <div class="column">
    <img class="relative z-20 w-full rounded-full " src="https://drive.google.com/uc?export=view&id=1s7J6rF7cuxV9VURP4I2gqf14CiU75tLI" height="200" width="200">
   <h3> <b> Rashmi Raveena </b></h3>
   <p class="text-blue-600">Frontend Developer</p>
    </div>
  </div>
</div>



   
             
                        
                  

            


								</div>
							</div>
						</div>		
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
</body>
</html>